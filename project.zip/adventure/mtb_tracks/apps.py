from django.apps import AppConfig


class MtbTracksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'adventure.mtb_tracks'
